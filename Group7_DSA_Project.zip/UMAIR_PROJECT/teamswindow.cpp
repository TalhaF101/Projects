#include "teamswindow.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <QString>
#include <QTableWidgetItem>
#include <QMessageBox>


using namespace std;

// --- TreeNode Implementation ---
TreeNode::TreeNode(const string &name, int rank, int members)
    : name(name), rank(rank), members(members), left(nullptr), right(nullptr) {}


// Getter methods
string TreeNode::getName() const { return name; }
int TreeNode::getRank() const { return rank; }
int TreeNode::getMembers() const { return members; }
TreeNode* TreeNode::getLeft() const { return left; }
TreeNode* TreeNode::getRight() const { return right; }

// Setter methods
void TreeNode::setLeft(TreeNode* node) { left = node; }
void TreeNode::setRight(TreeNode* node) { right = node; }



// Constructor initializes the root to nullptr
BinaryTree::BinaryTree() : root(nullptr) {}


// Recursive function to insert a node into the tree
TreeNode* BinaryTree::insert(TreeNode *node, const string &name, int rank, int members)
{
    if (node == nullptr)
        return new TreeNode(name, rank, members);

    if (rank < node->getRank())  // Use the getter method here
        node->setLeft(insert(node->getLeft(), name, rank, members));
    else
        node->setRight(insert(node->getRight(), name, rank, members));

    return node;
}

void BinaryTree::insert(const string &name, int rank, int members)
{
    root = insert(root, name, rank, members);
}


// Helper function for in-order traversal to populate tables
void BinaryTree::populateTableInOrder(TreeNode *node, QTableWidget *teamA_table, QTableWidget *teamB_table, int &rowA, int &rowB) const
{
    if (node == nullptr)  // Base case: return if the current node is nul
        return;

    // Traverse left subtree
    populateTableInOrder(node->getLeft(), teamA_table, teamB_table, rowA, rowB);

     // Populate Team A table if it has fewer than 8 rows
    if (rowA < 8)
    {
        // Populate Team A table
        teamA_table->setItem(rowA, 0, new QTableWidgetItem(QString::fromStdString(node->getName())));
        teamA_table->setItem(rowA, 1, new QTableWidgetItem(QString::number(node->getRank())));
        teamA_table->setItem(rowA, 2, new QTableWidgetItem(QString::number(node->getMembers())));
        ++rowA;
    }
    // Otherwise, populate Team B table
    else if (rowB < 8)
    {
        teamB_table->setItem(rowB, 0, new QTableWidgetItem(QString::fromStdString(node->getName())));
        teamB_table->setItem(rowB, 1, new QTableWidgetItem(QString::number(node->getRank())));
        teamB_table->setItem(rowB, 2, new QTableWidgetItem(QString::number(node->getMembers())));
        ++rowB;
    }

    // Traverse right subtree
    populateTableInOrder(node->getRight(), teamA_table, teamB_table, rowA, rowB);
}


// Public method to populate tables
void BinaryTree::populateTable(QTableWidget *teamA_table, QTableWidget *teamB_table) const
{
    int rowA = 0, rowB = 0; // Initialize counters for each table
    populateTableInOrder(root, teamA_table, teamB_table, rowA, rowB);
}

// Loads data from a file into the binary tree
void teamswindow::loadDataFromFile(const string &filePath)
{
    ifstream file(filePath);
    if (!file.is_open()) {
        // Prompt a message box for failure
        QMessageBox::critical(nullptr, "Error", "Could not open file: " + QString::fromStdString(filePath));
        return;
    }

    string line;
    bool dataLoaded = false;
    while (getline(file, line)) {
        istringstream stream(line);
        string name;
        int rank, members;

        if (getline(stream, name, ',') && stream >> rank && stream.ignore(1) && stream >> members) {
            tree.insert(name, rank, members);
            dataLoaded = true;
        }
    }

    file.close();

    // Notify if no valid data was loaded
    if (!dataLoaded) {
        QMessageBox::warning(nullptr, "Warning", "The file is empty or contains invalid data.");
    }
}

// Populates tables using the binary tree data
void teamswindow::populateTable(QTableWidget *TeamA_table ,QTableWidget *TeamB_table)
{
    tree.populateTable(TeamA_table ,TeamB_table);  // Populating table from the tree
}


// Constructor initialization for teamswindow
teamswindow::teamswindow(QWidget *parent) : QWidget(parent), tree() {}
