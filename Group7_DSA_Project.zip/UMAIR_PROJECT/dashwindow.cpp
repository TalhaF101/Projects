#include "dashwindow.h"
#include <QVBoxLayout>

dashwindow::dashwindow() {}


