#ifndef TEAMSWINDOW_H
#define TEAMSWINDOW_H

#include <QWidget>
#include <QTableWidget>
#include <string>
using namespace std;

class TreeNode
{
public:
    // Constructor to initialize a tree node with team details
    TreeNode(const string &name, int rank, int members);

    // Getter methods to access node properties
    string getName() const;
    int getRank() const;
    int getMembers() const;
    TreeNode* getLeft() const;
    TreeNode* getRight() const;

     // Setter methods to modify child pointers
    void setLeft(TreeNode* node);
    void setRight(TreeNode* node);

private:
    string name; // Team name
    int rank;    // Team rank
    int members; // Number of members in the team
    TreeNode *left, *right;  // Pointer to the left child node and right child node
};

// Represents a binary tree for storing and organizing teams
class BinaryTree
{
private:
 // Root of the binary tree
     TreeNode *root;

// Helper function to recursively insert a node
    TreeNode* insert(TreeNode *node, const string &name, int rank, int members);

 // Helper function to populate tables in order traversal
    void populateTableInOrder(TreeNode *node, QTableWidget *teamA_table, QTableWidget *teamB_table, int &rowA, int &rowB) const;


public:
 // Constructor initializes the tree
    BinaryTree();

 // Insert a new team into the tree
    void insert(const string &name, int rank, int members);

 // Populate tables with tree data
    void populateTable(QTableWidget *TeamA_table, QTableWidget *TeamB_table) const;
};

// Represents the main widget managing teams
class teamswindow : public QWidget
{
    Q_OBJECT

public:
// Constructor
    explicit teamswindow(QWidget *parent = nullptr);

// Load team data from a file
    void loadDataFromFile(const string &filePath);

// Populate tables with team data
    void populateTable(QTableWidget *TeamA_table ,QTableWidget *TeamB_table);

private:
// Binary tree to manage team data
    BinaryTree tree;
};

#endif // TEAMSWINDOW_H

