
#include "simulation.h"
#include <random>
#include <stdexcept>
#include <QMessageBox>

// Match constructor initializes teams, time, status, and winner.
Match::Match(const QString& team1, const QString& team2, const QString& time)
    : team1(team1), team2(team2), time(time), status("Scheduled"), winner("") {}

// Accessor methods
QString Match::getTeam1() const { return team1; }
QString Match::getTeam2() const { return team2; }
QString Match::getTime() const { return time; }
QString Match::getStatus() const { return status; }
QString Match::getWinner() const { return winner; }

// Setters methods
void Match::setStatus(const QString& status) { this->status = status; }
void Match::setWinner(const QString& winner) { this->winner = winner; }

// Stack Push and Pop Implementation
void Schedule::Stack::push(const QString& name)
{
    Node* newNode = new Node(name); // Create new node
    newNode->next = top;            // Link to top node
    top = newNode;                  // Update top
}

QString Schedule::Stack::pop()
{
    if (!top) throw std::runtime_error("Stack empty!");
    QString name = top->name;
    Node* temp = top;
    top = top->next;
    delete temp;
    return name;
}

bool Schedule::Stack::isEmpty()
{
    return top == nullptr; // Check if stack is empty
}

// Queue Enqueue and Dequeue Implementation
void Schedule::Queue::enqueue(const QString& name)
{
    Node* newNode = new Node(name);
    if (!rear) front = rear = newNode;  // If queue is empty
    else {
        rear->next = newNode;           // Add to the rear
        rear = newNode;
    }
}

QString Schedule::Queue::dequeue()
{
    if (!front) throw std::runtime_error("Queue empty!");
    QString name = front->name;
    Node* temp = front;
    front = front->next;
    if (!front) rear = nullptr;
    delete temp;
    return name;
}

bool Schedule::Queue::isEmpty()
{
    return front == nullptr;    // Check if queue is empty
}

// Schedule Constructor
Schedule::Schedule() {}

// Populate Round 1 with teams from Stack (Team A) and Queue (Team B)
void Schedule::populateRound1(QStackedWidget* stackedWidget, QTableWidget* teamA_table, QTableWidget* teamB_table)
{
    // Load Team A into Stack
    for (int i = 0; i < teamA_table->rowCount(); ++i)
        stack.push(teamA_table->item(i, 0)->text());

    // Load Team B into Queue
    for (int i = 0; i < teamB_table->rowCount(); ++i)
        queue.enqueue(teamB_table->item(i, 0)->text());

    // Populate Round 1 Labels
    for (int i = 1; i <= 8; ++i) {
        if (!stack.isEmpty() && !queue.isEmpty()) {
            QFrame* frame = stackedWidget->findChild<QFrame*>("R1_Frame_" + QString::number(i));
            QLabel* labelA = frame->findChild<QLabel*>("T_A_" + QString::number(i));
            QLabel* labelB = frame->findChild<QLabel*>("T_B_" + QString::number(i));

            labelA->setText(stack.pop());
            labelB->setText(queue.dequeue());
        }
    }
}

// Pick a random winner between two teams
QString Schedule::pickRandomWinner(const QString& teamA, const QString& teamB) {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 1);

    return dis(gen) == 0 ? teamA : teamB;
}

QStringList Schedule::round1Winners;
QStringList Schedule::round2Winners;
QStringList Schedule::round3Winners;
QStringList Schedule::finalWinner;

// Generate fixtures and determine winners
void Schedule::generateFixtures1(QStackedWidget* stackedWidget, int round) {

    switch (round)
    {
         // Generate fixtures for Round 1
    case 1:
    {
        for (int i = 1; i <= 8; ++i) {
            QFrame* frame = stackedWidget->findChild<QFrame*>("R1_Frame_" + QString::number(i));
            if (frame) {
                QLabel* labelA = frame->findChild<QLabel*>("T_A_" + QString::number(i));
                QLabel* labelB = frame->findChild<QLabel*>("T_B_" + QString::number(i));

                QString teamA = labelA ? labelA->text() : "";
                QString teamB = labelB ? labelB->text() : "";

                if (!teamA.isEmpty() && !teamB.isEmpty()) {
                    QString winner = pickRandomWinner(teamA, teamB);
                    round1Winners.append(winner);
                }
            }
        }

        for (int i = 1; i <= 4; ++i) {
            QFrame* frame = stackedWidget->findChild<QFrame*>("R2_Frame_" + QString::number(i));
            if (frame) {
                QLabel* label1 = frame->findChild<QLabel*>("F_" + QString::number(2 * i - 1) + "_W");
                QLabel* label2 = frame->findChild<QLabel*>("F_" + QString::number(2 * i) + "_W");

                if (label1 && round1Winners.size() >= 2 * i - 1) {
                    label1->setText(round1Winners[2 * i - 2]); // Winner from Match 2*i-1
                }
                if (label2 && round1Winners.size() >= 2 * i) {
                    label2->setText(round1Winners[2 * i - 1]); // Winner from Match 2*i
                }
            }
        }

        break;
    }

// Generate fixtures for Round 2 using winners from Round 1
    case 2:
    {

        // Generate fixtures for Round 2
        for (int i = 1; i <= 4; ++i) {
            QFrame* frame = stackedWidget->findChild<QFrame*>("R2_Frame_" + QString::number(i));
            if (frame) {
                QLabel* label1 = frame->findChild<QLabel*>("F_" + QString::number(2 * i - 1) + "_W");
                QLabel* label2 = frame->findChild<QLabel*>("F_" + QString::number(2 * i) + "_W");

                if (label1 && round1Winners.size() >= 2 * i - 1) {
                    label1->setText(round1Winners[2 * i - 2]); // Winner from Match 2*i-1
                }
                if (label2 && round1Winners.size() >= 2 * i) {
                    label2->setText(round1Winners[2 * i - 1]); // Winner from Match 2*i
                }

                // Determine the winner for this frame
                QString teamA = label1 ? label1->text() : "";
                QString teamB = label2 ? label2->text() : "";
                if (!teamA.isEmpty() && !teamB.isEmpty()) {
                    QString winner = pickRandomWinner(teamA, teamB);
                    round2Winners.append(winner);
                }
            }
        }
        // Generate winners for Semi-finals
        // Frame 1: Semi_1 and Semi_2
        QFrame* semiFrame1 = stackedWidget->findChild<QFrame*>("R3_Frame_1");
        if (semiFrame1) {
            QLabel* labelSemi1 = semiFrame1->findChild<QLabel*>("Semi_1");
            QLabel* labelSemi2 = semiFrame1->findChild<QLabel*>("Semi_2");

            // Assign round2Winners[0] to Semi_1
            if (labelSemi1 && round2Winners.size() > 0) {
                labelSemi1->setText(round2Winners[0]);
            }
            // Assign round2Winners[2] to Semi_2
            if (labelSemi2 && round2Winners.size() > 2) {
                labelSemi2->setText(round2Winners[2]);
            }
        }

        // Frame 2: Semi_3 and Semi_4
        QFrame* semiFrame2 = stackedWidget->findChild<QFrame*>("R3_Frame_2");
        if (semiFrame2) {
            QLabel* labelSemi3 = semiFrame2->findChild<QLabel*>("Semi_3");
            QLabel* labelSemi4 = semiFrame2->findChild<QLabel*>("Semi_4");

            // Assign round2Winners[1] to Semi_3
            if (labelSemi3 && round2Winners.size() > 1) {
                labelSemi3->setText(round2Winners[1]);
            }
            // Assign round2Winners[3] to Semi_4
            if (labelSemi4 && round2Winners.size() > 3) {
                labelSemi4->setText(round2Winners[3]);
            }
        }
        break;
    }

// Generate fixtures for the Final using winners from Round 2
    case 3:
    {

        // Determine the winner for this semi-final match
        if (!round2Winners.isEmpty() && round2Winners.size() > 1) {
            QString winner1 = pickRandomWinner(round2Winners[0], round2Winners[2]);
            round3Winners.append(winner1);  // Store the winner
        }

        // Determine the winner for this semi-final match
        if (!round2Winners.isEmpty() && round2Winners.size() > 3) {
            QString winner2 = pickRandomWinner(round2Winners[1], round2Winners[3]);
            round3Winners.append(winner2);  // Store the winner
        }

        // Generate fixtures for the Final match using the winners from round 3
        QFrame* finalFrame = stackedWidget->findChild<QFrame*>("Final_Frame");
        if (finalFrame) {
            QLabel* labelF1 = finalFrame->findChild<QLabel*>("F_1");
            QLabel* labelF2 = finalFrame->findChild<QLabel*>("F_2");

            // Retrieve winners from round 3
            QString teamFinal1 = round3Winners.size() > 0 ? round3Winners[0] : "";
            QString teamFinal2 = round3Winners.size() > 1 ? round3Winners[1] : "";

            // Set the teams in the final match labels
            if (labelF1) labelF1->setText(teamFinal1);
            if (labelF2) labelF2->setText(teamFinal2);


        }
        break;
    }

// Determine the winner of the final match
    case 4:
    {
        // Retrieve winners from round 3
        QString teamFinal1 = round3Winners.size() > 0 ? round3Winners[0] : "";
        QString teamFinal2 = round3Winners.size() > 1 ? round3Winners[1] : "";

        // Determine the winner of the final match
        if (!teamFinal1.isEmpty() && !teamFinal2.isEmpty()) {
            QString winner = pickRandomWinner(teamFinal1, teamFinal2);

            // Store the final winner
            finalWinner.append(winner);
        }

        // Display the overall tournament winner
        if (finalWinner.size() > 0) {
            QString tournamentWinner = finalWinner[0]; // The winner of the final match
            QMessageBox::information(nullptr, "Tournament Winner",
                                     "The winner of the tournament is: " + tournamentWinner);
        } else {
            qWarning() << "No final winner found!";
        }
        break;
    }

    default:
        qWarning() << "Invalid round number: " << round;
        break;
    }
}

// Implement the static getter methods
QStringList Schedule::getRound1Winners()
{
    return round1Winners;
}

QStringList Schedule::getRound2Winners()
{
    return round2Winners;
}

QStringList Schedule::getRound3Winners()
{
    return round3Winners;
}

QStringList Schedule::getFinalWinner()
{
    return finalWinner;
}


