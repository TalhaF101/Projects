#ifndef HOMEWINDOW_H
#define HOMEWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui {
class HomeWindow;
}
QT_END_NAMESPACE

class HomeWindow : public QMainWindow
{
    Q_OBJECT

public:
    HomeWindow(QWidget *parent = nullptr);
    ~HomeWindow();

private slots:


    void on_HOME_Button_clicked();

    void on_Dash_Button_clicked();

    void on_Teams_Button_clicked();

    void on_TimeTable_Button_clicked();

    void on_Simulation_Button_clicked();

    void on_Fixture_Button_1_clicked();



    void on_Help_Button_clicked();

private:
    Ui::HomeWindow *ui;
    int fixtureRoundCounter = 0;
    bool teamsLoaded = false; // To track if teams are already loaded
    bool timeTablePopulated = false;
};
#endif // HOMEWINDOW_H
