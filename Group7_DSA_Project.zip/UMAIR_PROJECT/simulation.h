#ifndef SIMULATION_H
#define SIMULATION_H

#include <QWidget>
#include <QString>
#include <QTableWidget>
#include <QStackedWidget>
#include <QList>
#include <QFrame>
#include <QLabel>
#include <stdexcept>

// Match class represents a match between two teams.
class Match
{
public:
    Match(const QString& team1, const QString& team2, const QString& time);

// Accessor methods to get team names, time, status, and winner.
    QString getTeam1() const;
    QString getTeam2() const;
    QString getTime() const;
    QString getStatus() const;
    QString getWinner() const;

// setters methods to set status and winner.
    void setStatus(const QString& status);
    void setWinner(const QString& winner);

private:
    QString team1;
    QString team2;
    QString time;
    QString status;  // Scheduled/Completed
    QString winner;  // Winner team name
};

// Schedule class handles scheduling matches and managing winners.
class Schedule
{
public:
    Schedule();  // Constructor

// Methods to pick a random winner between two teams.
     QString pickRandomWinner(const QString& teamA, const QString& teamB);

// Static lists to store winners of each round.
     static QStringList round1Winners ;
     static QStringList round2Winners;
     static QStringList round3Winners;
     static QStringList finalWinner;

// Static getter methods for the round winners
    static QStringList getRound1Winners();
    static QStringList getRound2Winners();
    static QStringList getRound3Winners();
    static QStringList getFinalWinner();

// Methods for populating rounds and generating fixtures
    void populateRound1(QStackedWidget* stackedWidget, QTableWidget* teamA_table, QTableWidget* teamB_table);
    void generateFixtures1(QStackedWidget* stackedWidget, int round);


private:
    // Internal classes for Stack and Queue
    class Node
    {
    public:
        QString name;
        Node* next;
        Node(const QString& name) : name(name), next(nullptr) {}
    };

// Stack class to manage teamA (push/pop operations)
    class Stack
    {
    public:
        Stack() : top(nullptr) {}
        void push(const QString& name);
        QString pop();
        bool isEmpty();

    private:
        Node* top;
    };

 // Queue class to manage teamB (enqueue/dequeue operations)
    class Queue
    {
    public:
        Queue() : front(nullptr), rear(nullptr) {}
        void enqueue(const QString& name);
        QString dequeue();
        bool isEmpty();

    private:
        Node* front;
        Node* rear;
    };

    Stack stack;  // Stack for Team A
    Queue queue;  // Queue for Team B
};

#endif // SIMULATION_H
