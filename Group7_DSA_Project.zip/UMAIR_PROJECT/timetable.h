#ifndef TIMETABLE_H
#define TIMETABLE_H
#include "simulation.h"
#include <QWidget>
#include <QString>
#include <QTableWidget>
#include <QStackedWidget>
#include <QList>
#include <QFrame>
#include <QLabel>
#include <stdexcept>



// Timings class definition
class Timings
{
public:
    Timings(const QString& team1, const QString& team2, const QString& time);

// Getter methods to access the properties of the match
    QString getTeam1() const;
    QString getTeam2() const;
    QString getTime() const;
    QString getStatus() const;
    QString getWinner() const;

// Setter methods to modify match status and winner
    void setStatus(const QString& status);
    void setWinner(const QString& winner);

private:
    QString team1;  // Name of Team 1
    QString team2;  // Name of Team 2
    QString time;   // Scheduled time of the match
    QString status; // Scheduled/Completed
    QString winner; // Winner team name
};

// The TimeTable class manages the tournament schedule, populating match details in a table.
class TimeTable
{
public:
    TimeTable();

// Methods to populate different rounds' match schedules
    void populateTimeTable(QTableWidget* teamA_table, QTableWidget* teamB_table, QTableWidget* Time_Table);
    void populateRound2Table(QTableWidget* Time_Table, QTableWidget* Time_Table_2);
    void populateRound3Table(QTableWidget* Time_Table_2, QTableWidget* Time_Table_3);
    void displayFinalWinner(QLabel* winner_show);
    void updateWinnersColumn(QTableWidget* Time_Table);



private:

 // Node class to be used in the custom Stack and Queue data structures
    class Node
    {
    public:
        QString name;   // Team name
        Node* next;     // Pointer to the next node in the stack/queue
        Node(const QString& name) : name(name), next(nullptr) {}
    };

 // Stack implementation using a linked list
    class Stack
    {
    public:
        Stack() : top(nullptr) {}        // Initialize the top pointer to nullptr
        void push(const QString& name);  // Push team name onto stack
        QString pop();                   // Pop team name from stack
        bool isEmpty();                  // Check if the stack is empty

    private:
        Node* top;  // Top of the stack
    };

// Queue implementation using a linked list
    class Queue
    {
    public:
        Queue() : front(nullptr), rear(nullptr) {}  // Initialize front and rear pointers
        void enqueue(const QString& name);          // Add team to the queu
        QString dequeue();                          // Remove team from the front of the queue
        bool isEmpty();                             // Check if the queue is empty

    private:
        Node* front;    // Front of the queue
        Node* rear;     // Rear of the queue
    };

    Stack stack;  // Stack for Team A
    Queue queue;  // Queue for Team B
};



#endif // TIMETABLE_H
