#include "timetable.h"
#include "simulation.h"
#include <stdexcept>
#include <QMessageBox>
#include <QDebug>
#include <QRandomGenerator>

// Constructor for Timings class, initializes match details
Timings::Timings(const QString& team1, const QString& team2, const QString& time)
    : team1(team1), team2(team2), time(time), status("Scheduled"), winner("") {}

// Accessor methods
QString Timings::getTeam1() const { return team1; }
QString Timings::getTeam2() const { return team2; }
QString Timings::getTime() const { return time; }
QString Timings::getStatus() const { return status; }
QString Timings::getWinner() const { return winner; }

// Setters methods
void Timings::setStatus(const QString& status) { this->status = status; }
void Timings::setWinner(const QString& winner) { this->winner = winner; }


// Stack Push and Pop Implementation
void TimeTable::Stack::push(const QString& name)
{
    Node* newNode = new Node(name);
    newNode->next = top;
    top = newNode;
}

// Stack method to pop a team name from the stack
QString TimeTable::Stack::pop()
{
    if (!top) throw std::runtime_error("Stack empty!");
    QString name = top->name;   // Save the team name at the top
    Node* temp = top;           // Temporarily store the top node
    top = top->next;            // Move top to the next node
    delete temp;                // Delete the old top node
    return name;                // Return the popped team name
}

// Check if the stack is empty
bool TimeTable::Stack::isEmpty()
{
    return top == nullptr;
}

// Queue method to enqueue a team name to the queue
void TimeTable::Queue::enqueue(const QString& name)
{
    Node* newNode = new Node(name);      // Create a new node
    if (!rear) front = rear = newNode;   // If queue is empty, both front and rear point to new node
    else
    {
        rear->next = newNode;            // Point the current rear to the new node
        rear = newNode;                  // Move rear to the new node
    }
}

// Queue method to dequeue a team name from the queue
QString TimeTable::Queue::dequeue()
{
    if (!front) throw std::runtime_error("Queue empty!");   // Check if queue is empty
    QString name = front->name;                             // Get team name at the front of the queue
    Node* temp = front;                                     // Temporarily store the front node
    front = front->next;                                    // Move front to the next node
    if (!front) rear = nullptr;                             // If queue is empty after dequeue, set rear to nullptr
    delete temp;                                            // Delete the old front node
    return name;                                            // Return the dequeued team name
}

// Check if the queue is empty
bool TimeTable::Queue::isEmpty()
{
    return front == nullptr;
}

// Constructor for TimeTable
TimeTable::TimeTable() {}



/* This method populates the Time Table for Round 1 with match schedules.
It takes in the teamA_table (with team A's names), teamB_table (with team B's names),
and Time_Table (which will display the match schedule).*/

void TimeTable::populateTimeTable(QTableWidget* teamA_table, QTableWidget* teamB_table, QTableWidget* Time_Table) {
    // Clear existing rows in the Time Table
    Time_Table->setRowCount(0);

    int rowCount = 0;  // For keeping track of rows in Time Table

    // Define the static match times
    QStringList matchTimes = {
        "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
        "01:00 PM", "02:00 PM", "03:00 PM"
    };

    // Load Team A into stack
    for (int i = 0; i < teamA_table->rowCount(); ++i)
        stack.push(teamA_table->item(i, 0)->text());

    // Load Team B into queue
    for (int i = 0; i < teamB_table->rowCount(); ++i)
        queue.enqueue(teamB_table->item(i, 0)->text());

    // Fetch existing winners from the schedule
    QStringList winners = Schedule::getRound1Winners();

    // Populate the table with 8 rounds of matches
    for (int i = 0; i < 8; ++i) {
        if (!stack.isEmpty() && !queue.isEmpty()) {
            // Pop team names from stack and dequeue from queue
            QString teamA = stack.pop();
            QString teamB = queue.dequeue();

            // Assign match time in the static order
            QString matchTime = matchTimes[i];  // Assign the time from the list based on the current index

            // Set the match status and winner
            QString matchStatus = "Scheduled";  // Default status is "Scheduled"
            QString matchWinner = "TBD";  // Default to "TBD" if no winner is available

            // If a winner exists for this match, set the winner and change status to "Completed"
            if (i < winners.size() && !winners[i].isEmpty()) {
                matchWinner = winners[i];
                matchStatus = "Completed";  // Set status to "Completed" when there's a winner
            }

            // Insert the match details into the Time Table (create a new row for each match)
            Time_Table->insertRow(rowCount);

            // Set the team names, match time, status, and winner in the Time Table
            Time_Table->setItem(rowCount, 0, new QTableWidgetItem(teamA));
            Time_Table->setItem(rowCount, 1, new QTableWidgetItem(teamB));
            Time_Table->setItem(rowCount, 2, new QTableWidgetItem(matchStatus));
            Time_Table->setItem(rowCount, 3, new QTableWidgetItem(matchWinner));
            Time_Table->setItem(rowCount, 4, new QTableWidgetItem(matchTime));

            ++rowCount; // Move to the next row in the Time Table
        }
    }
}



/* This method populates the Time Table for Round 2 based on the results of Round 1.
It takes in Time_Table (Round 1's Time Table) and Time_Table_2 (Round 2's Time Table)
 and updates Time_Table_2 with the new match schedules.*/

void TimeTable::populateRound2Table(QTableWidget* Time_Table, QTableWidget* Time_Table_2) {
    // Clear existing rows in the Round 2 Table
    Time_Table_2->setRowCount(0);

    // Define the static match times for Round 2
    QStringList matchTimes = {
        "08:00 AM", "09:00 AM", "10:00 AM", "11:00 AM"
    };

    // Fetch the winners from Round 1 (team names in the 4th column of the Round 1 table)
    QStringList round1Winners;
    for (int i = 0; i < Time_Table->rowCount(); ++i) {
        QString winner = Time_Table->item(i, 3)->text();  // Get the winner from the 4th column (Match Winner)
        if (!winner.isEmpty()) {
            round1Winners.append(winner);  // Store the winner
        }
    }

    // Fetch the Round 2 winners from the schedule (assuming it's available through this function)
    QStringList winners = Schedule::getRound2Winners();

    // Populate the Round 2 table with alternating winners in Team 1 and Team 2 columns
    int rowCount = 0;
    int matchTimeIndex = 0;  // Index to assign match times from matchTimes list

    for (int i = 0; i < round1Winners.size(); i += 2) {
        // Ensure we don't go out of bounds
        if (i + 1 < round1Winners.size()) {
            QString team1 = round1Winners[i];
            QString team2 = round1Winners[i + 1];

            // Insert a new row for each pair of teams
            Time_Table_2->insertRow(rowCount);

            // Set Team 1 and Team 2 in the Round 2 Table
            Time_Table_2->setItem(rowCount, 0, new QTableWidgetItem(team1));  // Team 1
            Time_Table_2->setItem(rowCount, 1, new QTableWidgetItem(team2));  // Team 2

            // Assign match time from the predefined list
            QString matchTime = (matchTimeIndex < matchTimes.size()) ? matchTimes[matchTimeIndex] : "TBD";
            matchTimeIndex++;  // Move to the next match time

            // Determine match status and winner
            QString matchStatus = "Scheduled";
            QString matchWinner = "TBD";
            if (rowCount < winners.size() && !winners[rowCount].isEmpty()) {
                matchWinner = winners[rowCount];
                matchStatus = "Completed";  // Set status to "Completed" when there's a winner
            }

            // Set match status and winner in the table
            Time_Table_2->setItem(rowCount, 2, new QTableWidgetItem(matchStatus));  // Match Status
            Time_Table_2->setItem(rowCount, 3, new QTableWidgetItem(matchWinner));  // Match Winner
            Time_Table_2->setItem(rowCount, 4, new QTableWidgetItem(matchTime));  // Match Time

            ++rowCount;  // Move to the next row
        }
    }
}



/* This method populates the Time Table for Round 3 based on the results of Round 2.
 It updates Time_Table_3 with match schedules for Round 3.*/

void TimeTable::populateRound3Table(QTableWidget* Time_Table_2, QTableWidget* Time_Table_3) {
    // Clear existing rows in the Round 3 Table
    Time_Table_3->setRowCount(0);

    // Define the static match times for Round 3
    QStringList matchTimes = {
        "01:00 PM", "02:00 PM"
    };

    // Fetch the winners from Round 2 (team names in the 4th column of the Round 2 table)
    QStringList round2Winners;
    for (int i = 0; i < Time_Table_2->rowCount(); ++i) {
        QString winner = Time_Table_2->item(i, 3)->text();  // Get the winner from the 4th column (Match Winner)
        if (!winner.isEmpty()) {
            round2Winners.append(winner);  // Store the winner
        }
    }

    // Fetch the Round 3 winners from the schedule (assuming it's available through this function)
    QStringList winners = Schedule::getRound3Winners();

    // Populate the Round 3 table with alternating winners in Team 1 and Team 2 columns
    int rowCount = 0;
    int matchTimeIndex = 0;  // Index to assign match times from matchTimes list

    // Ensure alternate pairing logic
    for (int i = 0; i < round2Winners.size() / 2; ++i) {
        QString team1 = round2Winners[i * 2];       // First and third elements
        QString team2 = round2Winners[i * 2 + 1];   // Second and fourth elements

        // Insert a new row for each pair of teams
        Time_Table_3->insertRow(rowCount);

        // Set Team 1 and Team 2 in the Round 3 Table
        Time_Table_3->setItem(rowCount, 0, new QTableWidgetItem(team1));  // Team 1
        Time_Table_3->setItem(rowCount, 1, new QTableWidgetItem(team2));  // Team 2

        // Assign match time from the predefined list
        QString matchTime = (matchTimeIndex < matchTimes.size()) ? matchTimes[matchTimeIndex] : "TBD";
        matchTimeIndex++;  // Move to the next match time

        // Determine match status and winner
        QString matchStatus = "Scheduled";
        QString matchWinner = "TBD";
        if (rowCount < winners.size() && !winners[rowCount].isEmpty()) {
            matchWinner = winners[rowCount];
            matchStatus = "Completed";  // Set status to "Completed" when there's a winner
        }

        // Set match status and winner in the table
        Time_Table_3->setItem(rowCount, 2, new QTableWidgetItem(matchStatus));  // Match Status
        Time_Table_3->setItem(rowCount, 3, new QTableWidgetItem(matchWinner));  // Match Winner
        Time_Table_3->setItem(rowCount, 4, new QTableWidgetItem(matchTime));  // Match Time

        ++rowCount;  // Move to the next row
    }
}



/*  This method displays the final winner of the competition in the specified QLabel widget.
 It takes in winner_show (a QLabel where the winner will be displayed).*/

void TimeTable::displayFinalWinner(QLabel* winner_show) {
    // Fetch the final winner from the Schedule
    QStringList winners = Schedule::getFinalWinner();

    // Check if the winners list is empty
    if (winners.isEmpty() || winners[0].isEmpty()) {
        winner_show->setText("The final winner has not been decided yet.");
        return;
    }

    // Get the final winner's name
    QString finalWinner = winners[0]; // Assuming the first entry contains the final winner's name

    // Display the final winner
    winner_show->setText("Champion: " + finalWinner);
}
