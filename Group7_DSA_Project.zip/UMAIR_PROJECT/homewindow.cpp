#include "homewindow.h"
#include "ui_homewindow.h"
#include "teamswindow.h"
#include "simulation.h"
#include "timetable.h"
#include <QPixmap>

using namespace std;

HomeWindow::HomeWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::HomeWindow)
    , fixtureRoundCounter(1)
{

    ui->setupUi(this);

    // Set the stacked widget's initial index
    ui->stackedWidget->setCurrentIndex(0);

    // Load the image
    QPixmap pixmap("D:/UNI/..Thrid Sem/DSA/PROJECT/QT/Home_Picture2.jpg");
    ui->Home_Background->setPixmap(pixmap);
    ui->Home_Background->setScaledContents(true); // Scale image to fit the label
}

HomeWindow::~HomeWindow()
{
    delete ui;
}

void HomeWindow::on_HOME_Button_clicked()
{
 ui->stackedWidget->setCurrentIndex(0);
}


void HomeWindow::on_Dash_Button_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);

    // Load the image
    QPixmap pixmap("D:/UNI/..Thrid Sem/DSA/PROJECT/QT/Icons/PurpleFC.png");
    ui->Dash_Background->setPixmap(pixmap);
    ui->Dash_Background->setScaledContents(true); // Scale image to fit the label
}


void HomeWindow::on_Teams_Button_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);

    teamswindow tWindow;

    // Load the image
    QPixmap pixmap("D:/UNI/..Thrid Sem/DSA/PROJECT/QT/Icons/tech.jpg");
    ui->Teams_Background->setPixmap(pixmap);
    ui->Teams_Background->setScaledContents(true); // Scale image to fit the label

    // Load data and show appropriate Teams
    tWindow.loadDataFromFile("C:/Users/Itcomplex/Desktop/Teams.txt");
    tWindow.populateTable(ui->TeamA_table, ui->TeamB_table);
}


void HomeWindow::on_TimeTable_Button_clicked()
{

    ui->stackedWidget->setCurrentIndex(3);

    TimeTable timeTable;
    teamswindow tWindow;

    // Load the image
    QPixmap pixmap("D:/UNI/..Thrid Sem/DSA/PROJECT/QT/Icons/TimeTable.jpg");
    ui->TimeTable_Background->setPixmap(pixmap);
    ui->TimeTable_Background->setScaledContents(true);
    ui->R1_background->setPixmap(pixmap);
    ui->R1_background->setScaledContents(true); // Scale image to fit the label
    ui->R2_background->setPixmap(pixmap);
    ui->R2_background->setScaledContents(true);
    ui->R3_background->setPixmap(pixmap);
    ui->R3_background->setScaledContents(true);

    tWindow.loadDataFromFile("C:/Users/Itcomplex/Desktop/Teams.txt");
    tWindow.populateTable(ui->TeamA_table, ui->TeamB_table);

    timeTable.populateTimeTable(ui->TeamA_table, ui->TeamB_table, ui->Time_Table);
    timeTable.populateRound2Table(ui-> Time_Table, ui-> Time_Table_2);
    timeTable.populateRound3Table(ui-> Time_Table_2, ui-> Time_Table_3);
    timeTable.displayFinalWinner(ui->winner_show);

    timeTablePopulated = true;  // Mark the table as populated
}


void HomeWindow::on_Simulation_Button_clicked()
{

    // Set the stacked widget's initial index
    ui->stackedWidget->setCurrentIndex(4);

    Schedule schedule;
    teamswindow tWindow;

    // Load the image
    QPixmap pixmap("D:/UNI/..Thrid Sem/DSA/PROJECT/QT/Icons/BlueFC.png");
    ui->Simulation_Background->setPixmap(pixmap);
    ui->Simulation_Background->setScaledContents(true); // Scale image to fit the label





    // Load data and show appropriate messages
    tWindow.loadDataFromFile("C:/Users/Itcomplex/Desktop/Teams.txt");
    tWindow.populateTable(ui->TeamA_table, ui->TeamB_table);

    // Use the actual names of the tables from your UI file
    QTableWidget* teamA_table = ui->TeamA_table;  // Ensure this name is correct in ui file
    QTableWidget* teamB_table = ui->TeamB_table;  // Ensure this name is correct in ui file

    // Populate round 1 with the teams
    schedule.populateRound1(ui->stackedWidget, teamA_table, teamB_table);
}


void HomeWindow::on_Fixture_Button_1_clicked()
{
    Schedule schedule;
    schedule.generateFixtures1(ui->stackedWidget, fixtureRoundCounter);
    qDebug() << "Round 1 Winners:" << Schedule::getRound1Winners();
    qDebug() << "Round 2 Winners:" << Schedule::getRound2Winners();
    qDebug() << "Round 3 Winners:" << Schedule::getRound3Winners();
    qDebug() << "Winners:" << Schedule::getFinalWinner();
    fixtureRoundCounter++;
}


void HomeWindow::on_Help_Button_clicked()
{
    ui->stackedWidget->setCurrentIndex(5);

}

