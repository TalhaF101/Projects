#ifndef DASHWINDOW_H
#define DASHWINDOW_H



class dashwindow
{
public:
    dashwindow();
};

#endif // DASHWINDOW_H
